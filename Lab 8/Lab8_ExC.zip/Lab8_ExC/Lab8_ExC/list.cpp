//
//  list.cpp
//  Lab8_ExC
//
//  Created by Carl  Soriano on 2022-11-23.
//
#include "list.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

FlowList::FlowList(): headM(nullptr){}

void FlowList::insert(const ListItem& itemA)
{
    Node *new_node = new Node;
    new_node->item = itemA;
    if (headM == nullptr || itemA.year <= headM->item.year) {
        new_node->next = headM;
        headM = new_node;
    }
    else {
        Node *before = headM;
        Node *after = headM->next;
        while(after != nullptr && itemA.year > after->item.year) {
            before = after;
            after = after->next;
        }
        new_node->next = after;
        before->next = new_node;
    }
}

void FlowList::remove(const ListItem& itemA)
{
    if (headM == 0 || itemA.year < headM->item.year)
        return;
    
    Node *doomed_node = 0;
    
    if (itemA.year == headM->item.year) {
        doomed_node = headM;
        headM = headM->next;
    }
    else {
        Node *before = headM;
        Node *maybe_doomed = headM->next;
        while(maybe_doomed != 0 && itemA.year > maybe_doomed->item.year) {
            before = maybe_doomed;
            maybe_doomed = maybe_doomed->next;
        }
        
        if(maybe_doomed == 0 || maybe_doomed->item.year != itemA.year)
            return;
        else {
            before->next = maybe_doomed->next;
            doomed_node = maybe_doomed;
        }
    }
    
    delete doomed_node;
}


void FlowList::print(){
    if (headM != 0) {
        cout<<headM->item.year<<"\t"<<headM->item.flow<<endl;
        for (const Node *p = headM->next; p != 0; p = p->next)
            cout<<p->item.year<<"\t"<<p->item.flow<<endl;
    }
}

bool FlowList::searchyear(const ListItem& source){
    Node* current = headM;
    
    while(current != nullptr){
        if(current->item.year == source.year)
            return true;
        current = current->next;
    }
    
    return false;
}

ListItem FlowList::getNode(const int& position) const{
    Node* current = headM;
    
    int i=0;
    while(current!=NULL){
        if(i == position){
            return current->item;
        }
        i++;
        current = current->next;
    }
    
    assert(0);
}

