//
//  list.hpp
//  Lab8_ExC
//
//  Created by Carl  Soriano on 2022-11-23.
//

#ifndef list_h
#define list_h

#include <stdio.h>

struct ListItem {
    
    int year;
    double flow;
};

struct Node {
    ListItem item;
    Node *next;
};

class FlowList{

public:
    FlowList(); 
    FlowList& operator =(const FlowList& rhs);
    void remove(const ListItem& itemA);
    void print();
    void insert(const ListItem& itemA);
    bool searchyear(const ListItem& source);
    ListItem getNode(const int& position) const;
private:
    Node *headM;

};


#endif 
