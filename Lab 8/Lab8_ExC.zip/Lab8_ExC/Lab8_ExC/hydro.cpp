//
//  hydro.cpp
//  Lab8_ExC
//
//  Created by Carl  Soriano on 2022-11-23.
//

#include "hydro.h"
#include "list.h"
#include <fstream>
#include <iostream>
using namespace std;


int main(void) {
    
    FlowList x;
    int numRecords;
    displayHeader();
    numRecords = readData(x);
    int quit =0;
    while(1)
    {
        switch(menu()){
            case 1:
                display(x, numRecords);
                pressEnter();
                break;
            case 2:
                addData(x, numRecords);
                pressEnter();
                break;
            case 3:
                saveData(x, numRecords);
                pressEnter();
                break;
            case 4:
                removeData(x, numRecords);
                pressEnter();
                break;
            case 5:
                cout << "\nProgram terminated!\n\n";
                quit = 1;
                break;
            default:
                cout << "\nNot a valid input.\n";
                pressEnter();
            
        }
        if(quit == 1) break;
        
    };
    // member functions inside flowlist class is what inserts the flow.txt file
    // also member functions of flowlist class keeps data in each node
    // read data calls on the text file and we use member functions in  flowlist class to add it into our list
    
}

void displayHeader(){
    
    cout<<"Program: Flow Studies - Fall 2022"<<endl;
    cout<<"Version: 1.0"<<endl;
    cout<<"Lab section: B01"<<endl;
    cout<<"Produced by: Carl Soriano"<<endl;
    
    cout<<"\n<<< Press Enter to Continue >>>"<<endl;
    cin.get();
    
}

int menu(){
    
    int select;
    cout<<"\nPlease select on the following operations:"<<endl;
    cout<<"\t1. Display flow list, and the average."<<endl;
    cout<<"\t2. Add data.\t"<<endl;
    cout<<"\t3. Save data into the file."<<endl;
    cout<<"\t4. Remove data."<<endl;
    cout<<"\t5. Quit."<<endl;
    cout<<"\nEnter your choice (1, 2, 3, 4, of 5): ";
    
    cin>>select;
    
    while(select < 1 || select > 5){
        cout<<"\nInvalid selection, please choose another selection: ";
        cin>>select;
    }
    
    return select;
}



int readData(FlowList& listA){
    int read = 0;
    string file_name = "/Users/carlsoriano/Downloads/ExerciseC/ExerciseC/flow.txt";
    
    ifstream inputf;
    inputf.open(file_name);
    
    if(inputf.fail()){
        cout<<"\nError opening file..."<<endl;
        exit(1);
    }
    
    ListItem itemA;
    while(!inputf.eof()){
        inputf>>itemA.year;
        inputf>>itemA.flow;
        if(inputf.eof()) break;
        
        listA.insert(itemA);
        read++;
    }
    
    inputf.close();
    return read;
}

void display(FlowList& listA, const int& numInstance){
    cout<<"\nYear\tFlow (billions of cubic meters)..."<<endl;
    listA.print();
    cout<<"\nThe annual average of the flow is: "<<average(listA, numInstance);
    cout<<" (billions of cubic meter)"<<endl;
}


void addData(FlowList& listA, int& numInstance){
    ListItem additem;
    
    cout<<"\nPlease enter a year: ";
    cin>>additem.year;
    cout<<"Please enter the flow: ";
    cin>>additem.flow;
    
    if(!listA.searchyear(additem)){
        listA.insert(additem);
        numInstance++;
        cout<<"\nNew record inserted successfully..."<<endl;
    }
    else{
        cout<<"\nError: duplicate data..."<<endl;
    }
}

void removeData(FlowList& listA, int& numInstance){
    ListItem rmvitem;
    
    cout<<"\nPlease enter the year you want to remove: ";
    cin>>rmvitem.year;

    if(!listA.searchyear(rmvitem)){
        cout<<"\nError: No such data exists..."<<endl;
    }
    else{
        cout<<"\nRecord was successfully removed..."<<endl;
        listA.remove(rmvitem);
        numInstance--;
    }
}

double average(FlowList& listA, const int& numInstance){
    double sum = 0, avgflow = 0;
    
    int iteration = 0;
    while(iteration < numInstance){
        ListItem nthNode = listA.getNode(iteration);
        sum += nthNode.flow;
        iteration++;
    }
    
    return avgflow = sum / numInstance;
}

void saveData(const FlowList& listA, const int& numInstance){
    string file_name = "/Users/carlsoriano/Downloads/ExerciseC/ExerciseC/flow.txt";
    
    ofstream outputf;
    outputf.open(file_name);
    
    int iteration = 0;
    while(iteration < numInstance){
        ListItem nthNode = listA.getNode(iteration);
        outputf<<nthNode.year<<"\t"<<nthNode.flow<<endl;
        iteration++;
    }
    
    cout<<"\nData saved into the file..."<<endl;
    outputf.close();
}

void pressEnter(){
    string input;
    
    cin.ignore();
    cout<<"\n<<< Press Enter to Continue >>>"<<endl;
    getline(cin, input);
}








