//
//  hydro.hpp
//  Lab8_ExC
//
//  Created by Carl  Soriano on 2022-11-23.
//

#ifndef hydro_h
#define hydro_h

#include <stdio.h>
#include "list.h"

void displayHeader();

int readData(FlowList& listA);

int menu();

void display(FlowList& listA, const int& numInstance);

void addData(FlowList& listA, int& numInstance);

void removeData(FlowList& listA, int& numInstance);

double average(FlowList& listA, const int& numInstance);

void saveData(const FlowList& listA, const int& numInstance);

void pressEnter(); 
#endif
